Epopeia demosystem Development Kit 1.4.0
by rgba demogroup
http://www.rgba.org

CREDITS:
-------
enlar		main code, concept
epsilum		additional code
r3d		concept
utopian		additional code

Third party code included:
urarlib		Christian Scheurer, Johannes Winkelmann
fmod		Firelight Technologies
bass		Ian Luck

Special thanks to Debi^GUM for the example script music.

GREETS:
------
BOAH
Centolos
Concept
Conspiracy
dust inc.
fuzzion
Groupe K
GUM
HardNULL
Mankind
Network
Ozone
Sector Omega
Spontz
Software Failure
Stravaganza
Threepixels
TLOTB
TPM
tpolm
xplsv
Zona Neutra

We love you all! :)


General demosystem description
------------------------------

The demosystem is contained in a DLL/so that exports the Epopeia API.

That API contains two parts:

A) Demo replay API, used by demo binary (epopeia.exe)

B) Plugin API, used to extend the demosystem using plugins.

As of Epopeia 1.4.0, there are four types of plugins:

- Startup menu plugin: used to show a GUI to the user
- Sound system plugin: this will play the demo music and provide 
  timing services.
- Graphics system plugin: this will initialize the graphics system 
  and perform framebuffer swapping each frame.
- Effect plugins: these can register new effects (classes) and
  utility functions in the script system 

The main idea behind the demosystem is as following:

1. All effects are plugins; this includes the 3D playing engine.

2. Effect plugins register one or more classes, that have some mandatory
methods and can have any amount of optional methods that will be callabe from
the script.

3. You can use any sound system (Fmod, Bass, Mikmod...)  and graphics library
(DirectX, OpenGL, SDL framebuffer, ...): the demosystem doesn't care about it.
Just prepare a plugin for the one you'd like to use.

4. The demo is sinchronized and "built" inside the script file "script.epo"
There you instantiate plugin classes to objects, that will be the effects.
You can create different objects of the same class with different parameters.
There you will also mark the loading points of effects, effect rendering start
and stops, each effect renderization order, etc.

For docs about how to write a demo script, read doc/epopeia.ENG.txt
For info about how to create a new plugin, read doc/plugin_api-1.4.txt
There is some info on legacy (pre-1.4) plugins on doc/plugin_api.txt,
it is safe to completely ignore it.

All the documentation is a work-in-progress, if you'd like something explained in
more detail or any information not found in the docs, please send me an email;
I'll be glad to hear from you.

Expect a full source-code release sometime in the future :)

enlar/rgba
enlar@rgba.org
2004 @ bcnparty


