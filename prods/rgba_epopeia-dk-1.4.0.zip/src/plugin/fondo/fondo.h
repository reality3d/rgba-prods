#ifndef FONDO_H
#define FONDO_H

typedef struct
{
 float R,G,B,A;	
}Fondo;

void Fondo_Register(void);


#endif
