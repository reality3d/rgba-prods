/* pngasmrd.h - assembler version of utilities to read a PNG file
 *
 * libpng 1.0.11 - April 27, 2001
 * For conditions of distribution and use, see copyright notice in png.h
 * Copyright (c) 2001 Glenn Randers-Pehrson
 *
 */

/* This file is obsolete in libpng-1.0.9 and later; its contents now appear
 * at the end of pngconf.h.
 */
