#ifndef TYPE_LIST
#define TYPE_LIST

#include "../list.h"

typedef TList TTypeList;

#endif // TYPE_LIST

