/*
 * Scripting grammar header
 * Epopeia Scripting Demo System
 *      by Enlar/RGBA
 *
 * Based on a groupwork for the faculty by 
 *		Jose Manuel Olaizola
 *		Mari Joxe Azurtza
 *      Eneko Lacunza (Enlar)
 *
 */
#ifndef GRAMMAR_H
#define GRAMMAR_H

#ifdef __cplusplus
extern "C" {
#endif

    void DemoScript(void);

#ifdef __cplusplus
};
#endif

    
#endif
