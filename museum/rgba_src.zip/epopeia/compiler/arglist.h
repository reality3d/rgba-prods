#ifndef EPOPEIA_ARGLIST
#define EPOPEIA_ARGLIST

#include "../list.h"

typedef TList TArgList;

#endif // EPOPEIA_ARGLIST

