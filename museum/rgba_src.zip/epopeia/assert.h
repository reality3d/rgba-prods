#ifndef EPOPEIA_ASSERT
#define EPOPEIA_ASSERT

#include "critical.h"

#endif

