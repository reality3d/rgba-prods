#ifndef DEMO_H
#define DEMO_H

extern void DemoSetName(char *Name);
extern char*DemoGetName(void);
extern void DemoSetStartMessage(char *Msg);
extern char*DemoGetStartMessage(void);
extern void DemoSetEndMessage(char *Msg);
extern char*DemoGetEndMessage(void);
extern void DemoSetModFile(char *Filename);
extern char*DemoGetModFile(void);


#endif /* DEMO_H */

