#ifndef R2TEXTURE_H
#define R2TEXTURE_H

#include <glt/glt.h>

typedef struct
{
 int sizex;
 int sizey;
 TTexture *texture;	
}R2Texture;

#endif