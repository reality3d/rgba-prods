#ifndef _EXTENSION_H_
#define _EXTENSION_H_

int EstaExtension( char *exten );

#endif
