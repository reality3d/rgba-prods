#ifndef _MISC_H_
#define _MISC_H_

extern "C"
{

int strmatch(char *pattern, char *cadena);

}

#endif

